<form>
	<h1>Mein Account</h1>	
	<div>
		<label id="nick"></label>
		<!-- wenn der Nutzer auf den Link klickt wird er ausgelogt -->
		<a href="index.php?action=logout" id="logout" >Logout</a>	
	</div>
</form>