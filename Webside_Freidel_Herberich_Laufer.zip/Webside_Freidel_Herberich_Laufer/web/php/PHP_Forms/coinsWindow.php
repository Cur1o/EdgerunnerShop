    <section class="cointsWindow">                                              <!-- section wird geöfnet -->
        <article id="coinsWindowArticle">                                       <!-- artivle wird geöfnet -->
            <form action="./" method="post">                                    <!-- Der Link führt auf die Startseite index.php zurück -->    
                <input type="hidden" name="button500" value="true"/>            <!-- verweist auf eine action in index.php -->
                <h2 class="realMoney">4.99€</h2>                                <!-- Der Preis der Münzen wird dagestellt -->
                <input type="image" src="images/Shopcoin500.png" alt="500"/>    <!-- Das Bild für die Münzen wird eingebunden -->              
            </form>                                                             <!-- form wird geschlossen -->
            <form action="./" method="post">                                    <!-- Der Link führt auf die Startseite index.php zurück -->
                <input type="hidden" name="button1000" value="true"/>           <!-- verweist auf eine action in index.php -->
                <h2 class="realMoney">9.99€</h2>                                <!-- Der Preis der Münzen wird dagestellt -->
                <input type="image" src="images/Shopcoin1000.png" alt="1000"/>  <!-- Das Bild für die Münzen wird eingebunden -->
            </form>                                                             <!-- form wird geschlossen -->
            <form action="./" method="post">                                    <!-- Der Link führt auf die Startseite index.php zurück -->
                <input type="hidden" name="button2000" value="true"/>           <!-- verweist auf eine action in index.php -->
                <h2 class="realMoney">19.99€</h2>                               <!-- Der Preis der Münzen wird dagestellt -->
                <input type="image" src="images/Shopcoin2000.png" alt="2000"/>  <!-- Das Bild für die Münzen wird eingebunden -->
            </form>                                                             <!-- form wird geschlossen -->
            <form action="./" method="post">                                    <!-- Der Link führt auf die Startseite index.php zurück -->
                <input type="hidden" name="button4000" value="true"/>           <!-- verweist auf eine action in index.php -->
                <h2 class="realMoney">39.99€</h2>                               <!-- Der Preis der Münzen wird dagestellt -->
                <input type="image" src="images/Shopcoin4000.png" alt="4000"/>  <!-- Das Bild für die Münzen wird eingebunden -->
            </form>                                                             <!-- form wird geschlossen -->
            <form action="./" method="post">                                    <!-- Der Link führt auf die Startseite index.php zurück -->
                <input type="hidden" name="button10000" value="true"/>          <!-- verweist auf eine action in index.php -->
                <h2 class="realMoney">99.99€</h2>                               <!-- Der Preis der Münzen wird dagestellt -->
                <input type="image" src="images/Shopcoin10000.png" alt="10000"/><!-- Das Bild für die Münzen wird eingebunden -->
            </form>                                                             <!-- form wird geschlossen -->
        </article>                                                              <!-- article wird geschlossen -->
</section>                                                                      <!-- section wird geschlossen -->
